"""Existing agent attendance responsibilities."""
