"""Core chat transcript responsibilities."""
