# Garage Core

Garage Core is the read-first ProcessForge layer for a project that already has
a `.pf` context. It lets an agent understand the project, search approved local
knowledge, and resolve selected resources before any governed work, Runtime
session, hook replay, chat transcript, Director, or multi-agent lease exists.

Use Garage to establish what the project permits before changing it. Governed
Work then records the selected process, scope, evidence and handoff so another
human or agent can verify and continue the result. See the shared
[requirements](../requirements.md) before setup.

## Levels

Level 1, Garage essentials:

- `pf.context` reads project identity, context freshness, selected process,
  authorized resources, search readiness, and active work summary.
- `pf.search` searches only resources authorized by the project snapshot.
- `pf.resolve` resolves a selected resource id from the same snapshot.
- Snapshot, local search index, resource manifests, templates, process metadata,
  and tool metadata are sufficient inputs.

Level 2, governed work:

- `pf.work.start` starts or continues governed work from a high-level
  objective, optionally with `process_id`. A project may authorize several
  processes, but the selected Work pins exactly one effective Process
  definition, version, fingerprint, active specialization set, selected
  resource identities, context snapshot, and assignment capsule. If selection
  is ambiguous, it returns compact `process_choice_required` candidates rather
  than inferring a process from the objective.
- `pf.work.state` returns the current stage, required inputs, obligations,
  artifacts, gates, blockers, and allowed outcomes.
- `pf.work.transition` accepts an outcome and evidence. ProcessForge resolves
  the next stage from YAML, updates the Assignment, emits stage events, and
  completes the Run after the final stage.
- run, task, assignment, capsule, artifact, review, log, and handoff files define
  durable work.
- agents start or continue governed work after they understand context and need
  to change files or produce delivery evidence.

Level 3, Forge orchestration:

- Runtime, Agent Ledger, hooks, session presence, heartbeat, chat, Director, and
  multi-agent coordination add orchestration and telemetry.
- these systems can enrich context and enforce live coordination, but they are
  not prerequisites for Level 1 context/search/resolve.

## Session Boundary

`project_root` is the authority for Garage reads. A supplied session id is
validated against Agent Ledger and must match the same project. The session is
reported as `session.status: bound`, but it does not promote Garage to Forge.
Forge mode follows the project/runtime coordination model, such as organized
Director-required coordination. Session-scoped views remain available through
`pf.session_context`, `pf.session_chat`, and `pf.session_activity`.

Session-scoped tools remain session-scoped. Garage tools do not read raw
provider payloads, do not create production sessions, and do not use a session as
the authorization source for resources.

## Search Readiness

Garage search reports one of four readiness states:

- `ready`: snapshot and index are fresh and indexed documents exist.
- `empty`: the search infrastructure is fresh but the authorized corpus has no
  indexed documents.
- `stale`: the index needs maintenance before trustworthy results.
- `blocked`: the project context or search setup is broken.

MCP may run bounded technical maintenance before a query when the index is
missing or stale. The search itself remains a pure query against the
snapshot-authorized index. Semantic changes, resource selection changes, or
unclear context updates require operator decision through the normal project
context flow.

## Resource Policy

Real article/documentation resources can opt into fulltext indexing. Large
source trees and SDK mirrors default to metadata navigation unless their
resource manifests explicitly select a small fulltext subset. Search never
falls back to workspace-wide file scanning, private home directories, web
search, or unselected workplace resources.

Project context separates the diagnostic `available_knowledge_resources`
catalog from the selected resource set. Only selected resources are copied to
`local_search_resources`, may be resolved by `pf.resolve`, and may contribute
to `pf.search`. A snapshot records `resource_selection` with the selection
mode, target platform versions, counts, and selector provenance.

The physical SQLite corpus is owned by the Workplace and is built only from
registered Workplace packages and templates. A project-local package, including
the generated `project-profile`, can be selected and resolved from that
project's context without adding a document to the shared corpus. Consequently,
a newly onboarded project with no selected registered Workplace document can
report a fresh `empty` search state: `pf.search` returns no documents, while
`pf.resolve` can still make its project profile available and `pf.work.start`
can start work. Register a reusable resource at the Workplace when it must be
searchable across the shared index.

Use `context_requirements.resource_selection.platform_versions` for a
data-driven platform target and explicit `knowledge_resources` selectors for
an override. A selector may use `id`, `preferred_version`, and `constraint`.
Older manifests without selectors use the narrow migration mode: direct
platform packages plus the newest compatible version of each logical resource.
For that migration only, selected documentation with a legacy metadata policy
is indexed as bounded text documentation; source-tree and symbol policies stay
metadata-only.

## Agent Path

The default agent path is:

1. read root `AGENTS.md` (explicit `.pf/AGENTS.md` fallback in an unmigrated project);
2. call `pf.context` with `project_root`; when MCP is unavailable, use the
   existing CLI and check the snapshot with `project-context-check`. Stop
   dependent work if context is missing, stale, invalid or blocked;
3. use `pf.search` for authorized project knowledge, templates, process, and
   tool metadata;
4. use `pf.resolve` before opening a resource root;
5. perform local read-only analysis;
6. for new work, call `pf.work.start` with the substantive objective. For existing
   work, discover and resume an exact [continuation](work-continuation.md);
7. retain the returned `run_id`, `assignment_id` and `context.id`. Without a bound
   session, pass these exact selectors to every Work state/transition call.
   Verify the Assignment and immutable capsule, including scope and permissions;
   satisfy the current obligations and call `pf.work.transition` with outcome
   and evidence. Use `pf.work.search`/`pf.work.resolve` for Work resources;
8. repeat until `action: run_completed`.

For a multi-process project, call `pf.work.start` with an offered `process_id`
after `process_choice_required`. `default` is a recommendation only: when more
than one process is allowed, it never silently chooses the Work process.
Completion can contain a handoff, next-work recommendation and an advisory
session-continuity recommendation. With no active Work, a fresh `pf.context`
can expose the latest relevant compact handoff continuation. Garage never
creates or restarts an external session, Runtime, MCP, or Ledger session.

Manual `run-create`, `task-create` and `task-complete` belong to the advanced
[task-batch workflow](../getting-started/task-batch-workflow.md). They are not
additional steps in this governed Work cycle. Its final transition writes the
Run summary and handoff automatically; completion does not close a host session.

The optional app-server runs Runtime scheduling for a workplace. The MCP host
starts and owns its separate stdio adapter. Neither a running app-server nor
host hooks are prerequisites for file-only Garage work. See
[Runtime model](runtime-model.md) for the ownership boundary.

## Work resources and executor handoff

Project navigation and [Work-scoped reads](work-resources.md) have different
authority boundaries. `pf.work.search` and `pf.work.resolve` require the exact
Run, Assignment and context id; their grants intersect pinned resources,
current authorization and the current stage subset. A ready project index
does not prove coverage of a particular Work.

The shared [execution contract](work-context.md) records intent, scope, sources
and outputs. A worker-ready assignment can produce [prepared input](prepared-input.md)
for an executor that does not use MCP. Collection records attributable results;
it does not advance the primary governed Work. After changing executor or
connection, compare the returned identity with the durable handoff before
continuing. These contracts do not depend on a particular model provider.
