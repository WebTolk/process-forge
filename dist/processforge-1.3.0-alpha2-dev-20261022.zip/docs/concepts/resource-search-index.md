# Resource Search Index

ProcessForge local search has three separate boundaries:

- versioned workplace resources declare what may be indexed;
- the workplace SQLite FTS5 index stores derived resource documents;
- the project context snapshot authorizes which resource ids a session may query.

Projects do not own search documents. They only carry allowed resource
identities and fingerprints in the snapshot. The private derived DB lives under:

```text
<workplace>/runtime/search/local-resource-search.sqlite
```

`pf.search` is a query adapter. It does not fall back to the full workplace,
other projects, home directories, Context7, the web, or a hidden `rg` pass over
large source trees.

Each result contains a stable `document_id`, `resource_id`, canonical relative
locator, provenance, and `match_reason` (`content` or `metadata`). The locator
is meaningful only while its snapshot remains current; agents use `pf.resolve`
for authorized private navigation rather than reconstructing resource roots.

## Indexing Policy

Resources use one reusable contract:

```yaml
indexing:
  enabled: true
  mode: fulltext # fulltext | metadata | none
  fields:
    - title
    - description
    - tags
  sources:
    - path: articles
      mode: fulltext
      include:
        - "**/*.md"
      exclude:
        - drafts/**
    - path: core/6.1.2
      mode: metadata
      role: source_tree
```

`fulltext` stores metadata plus selected text files in FTS. `metadata` stores
identity, title, description, version, root/path reference, and declared
metadata only. `none` excludes the resource from local search.

Large source trees, SDK mirrors, vendor trees, and multi-version platform
snapshots should use `metadata` unless their manifest explicitly selects a
small fulltext source. Search can return a navigation root, but Codex should use
normal filesystem reads and `rg` inside the selected root when it needs source
code detail.

## SQLite Model

The derived DB schema is resource-oriented:

```text
resources
documents
documents_fts
index_state
```

`resources` tracks `resource_id`, `resource_type`, `version`, `fingerprint`,
`indexing_policy_hash`, `root_ref`, and refresh status. `documents` tracks
`resource_id`, `relative_path`, `kind`, `title`, hashes, and JSON metadata.
`documents_fts` stores searchable fulltext fields. `index_state` stores the
Workplace catalogue state and project snapshot scopes in the same shared DB.
Project snapshots authorize resource ids per query; documents are not duplicated
for each project.

## CLI

```bash
python bin/pf.py search-index status --project-root <project> --workplace <workplace>
python bin/pf.py search-index refresh --project-root <project> --workplace <workplace>
python bin/pf.py search-index rebuild --project-root <project> --workplace <workplace>
python bin/pf.py search-index doctor --project-root <project> --workplace <workplace>
python bin/pf.py search-index tick --project-root <project> --workplace <workplace>
```

Every command requires a project root and reads its context snapshot. `status`
is read-only; `status --verify-files` checks authorized file fingerprints and
reports stale state when their content changed. `refresh` indexes resources
authorized by that snapshot, respecting `indexing.mode`. `rebuild` deletes the
derived DB and builds it again; `tick` performs one bounded pass for the project
snapshot scope.

`refresh`, `rebuild`, and `tick` require context status `fresh` or
`fresh_with_updates`; otherwise they refuse with exit code 1. `status` and
`doctor` remain available for other context states. `doctor` reports project
context freshness as `PASS` for these two states and `WARN` otherwise.

## Runtime And MCP

The physical Workplace catalogue is read by the concrete Core
`WorkplaceSearchCatalogReader`. It reads current registries, registered package
roots, active official knowledge packages and templates, then resolves their
path references. It requires no project context, CLI, Runtime, Ledger or session.
Maintenance and bounded session search-status projection use this reader directly;
the historical catalogue functions in the monolith delegate to it. This catalogue
does not grant a project permission to query any resource: project-scoped CLI/MCP
authorization and freshness checks still apply.

Runtime scheduling uses the existing Core `maintenance_tick` operation for the
Workplace catalogue, separately from the project-scoped CLI. This Core operation
does not enumerate projects or require a running Runtime, Ledger, or active
sessions. PF-owned resource mutations mark existing index state stale; external
file changes are detected by fingerprint verification during maintenance.

`pf.search` never reports stale data as `fresh`. If the index is missing, stale,
or degraded, the result carries that `search_status` and returns no matches
until maintenance refreshes the derived DB.

Index freshness is not the same as semantic corpus readiness. A project can
have a fresh SQLite/FTS index with zero authorized resources or zero indexed
documents. Garage readiness checks should therefore show both infrastructure
state and corpus state: snapshot freshness, SQLite/FTS availability, index
freshness, authorized resource count, and indexed document count.

`pf.search` requires a project root, fresh resource resolution, fresh index
state, and resources authorized by that project's snapshot. It does not require
a Ledger session, hooks, daemon, write access, browser automation, CI,
deployment, or any other capability that is unrelated to the read-only query.
When a session id is supplied, MCP verifies that the session is bound to the
same project and then treats the session as an enhancement, not as the
authorization source. For example:

```text
Joomla resources fresh
filesystem.write missing
-> pf.search works
-> write-dependent action remains blocked
```

`pf.session_context` exposes compact readiness:

```yaml
context_freshness:
  status: fresh
resource_readiness:
  status: fresh
execution_readiness:
  status: blocked
search:
  status: fresh
  generation: <index-generation>
  stale: false
```

Resolved local paths are request-local runtime data. Public snapshots and
artifacts keep `path_ref` references instead of private absolute paths.
