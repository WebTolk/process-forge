# Getting Started

ProcessForge starts with files, not services. A project flow lives under `.pf/`.
Python CLI is the canonical runtime.

Check [requirements and memory planning](requirements.md) first. For human-led
setup, use [guided workplace setup](getting-started/guided-workplace-setup.md);
the direct commands below are for operators with explicit paths and choices.

## Garage and Forge

| | Garage | Forge |
|---|---|---|
| Runtime daemon | Not required | Required when coordination uses it |
| MCP | Optional host-owned stdio process; CLI works without it | Host-owned stdio when selected |
| Ledger session | Not needed for `pf.context/search/resolve/work.start` | Used for orchestration |
| Hooks | Optional host telemetry | Forge admission checks; host telemetry when selected |
| Director | No | Yes when required by coordination |
| Runtime autostart | Not needed | Recommended/required |

The normal project-agent path is `pf.context -> pf.search -> pf.resolve ->
pf.work.start`. Current context outranks historical generated reports. Runtime,
MCP, hook, Ledger, and index maintenance are operator/advanced paths.
For existing Work, use [exact continuation](concepts/work-continuation.md).
For selected Work resources, use `pf.work.search` and `pf.work.resolve` with
the returned Run/assignment/context ids. Keep repository scratch in `.pf/tmp/`.

## Initialize A Workplace

```bash
python bin/pf.py workplace-init --workplace <workplace-root> --dry-run
python bin/pf.py workplace-init --workplace <workplace-root> --apply
python bin/pf.py doctor-workplace --root <workplace-root>
```

## Initialize A Project

```bash
python bin/pf.py project-onboard --project-root <project-root> --workplace <workplace-root> --type generic-software-project --dry-run
python bin/pf.py project-onboard --project-root <project-root> --workplace <workplace-root> --type generic-software-project --apply
python bin/pf.py doctor-project --project-root <project-root>
python bin/pf.py agent-start-prompt --project-root <project-root>
```

Project onboarding creates root `AGENTS.md`, `.pf/AGENTS.md`,
`.pf/agent-entry.json`, public/private manifests,
hooks, a local launcher, context snapshots and onboarding artifacts.
The generated `first-assignment.yaml` is a compatibility placeholder, not a
required stage or the ordinary Work selection. The workplace is not recreated.
START is no longer needed and is not generated; existing files are preserved.
Its absence is normal for status, doctor and deterministic repair.

Start from root `AGENTS.md` (explicit `.pf/AGENTS.md` fallback in an unmigrated project).
Verify `pf.context`, use relevant `pf.search`/`pf.resolve`, then `pf.work.start`.
Use its returned Run/assignment/capsule with `pf.work.state` and
`pf.work.transition` until `run_completed`; handle `process_choice_required`
from the offered choices. `agent-start-prompt` only prints current guidance,
without writing files. See [entry policy](concepts/agent-entry.md).

Inside a linked project, run:

```bash
pf doctor-project --project-root .
python .pf/runtime/bin/pf.py doctor-project --project-root .
```

If a command needs a flow root and `.pf/process-forge.yaml` is missing, it should
tell the operator to run `project-onboard --project-root <project-root>
--workplace <workplace-root> --type <project-type> --apply` instead of creating
root-layout files. `init-project` is a compatibility command name.

## Refresh Project Context

```bash
python bin/pf.py project-context-refresh --project-root <project-root>
python bin/pf.py project-context-check --project-root <project-root>
```

The refresh command writes:

```text
.pf/contexts/project-context.snapshot.yaml
.pf/contexts/project-context.snapshot.md
.pf/runtime/cache/workplace-context.snapshot.yaml
```

## Advanced: Start A Ledger Session

```bash
python bin/pf.py session-start --mode resume --project-root <project-root> --report-only
```

This is a Forge/operator diagnostic path. Garage does not require a manual
session. Session start reads the snapshot, reports freshness, writes private
telemetry, and emits events under `.pf/runtime/`.

## Advanced: Run An Assignment Directly

Assignments use YAML front matter or assignment YAML for machine-readable
metadata. Markdown body text is human-readable context.

```bash
python bin/pf.py assignment-capsule --project-root <project-root> --assignment .pf/assignments/example.md
```

The capsule is written to `.pf/contexts/assignment-capsules/` and includes the
snapshot checksum, assignment scope, capabilities, required outputs, telemetry
path, and event correlation id.

## Events And Hooks

Core commands emit events to:

```text
.pf/runtime/events/events.sqlite3
```

Hook matching can be tested without sending or writing payloads:

```bash
python bin/pf.py hooks-dispatch --project-root <project-root> --event-type session.ended --dry-run
```

Outbox delivery writes private payloads under `.pf/runtime/hooks/outbox/`:

```bash
python bin/pf.py hooks-dispatch --project-root <project-root> --event-type assignment.completed --outbox
```

Network send is disabled in the MVP.

## Chat Relay

Chat transcript capture is local and opt-in:

```bash
python bin/pf.py chat-record --project-root <project-root> --session-id session-demo --participant operator --role user --content "Start"
python bin/pf.py chat-export --project-root <project-root> --session-id session-demo --target wtaicc --outbox
```

`chat-record` writes `.pf/runtime/chat/transcripts/<session-id>.ndjson` and
emits `chat.message.recorded`. By default, exported payloads include metadata,
hashes, and local content references; full redacted content requires
`--include-content`.

## Validation

Run:

```bash
python tools/validate-process-forge-schemas.py
python tools/validate-process-forge-checksums.py
python tools/validate-public-cleanliness.py
python bin/pf.py events-validate --project-root .
python bin/pf.py doctor-context --project-root .
python bin/pf.py release-test --root .
```

`context-resolve` and `context-compile` are compatibility-only commands. New
project instructions should use `.pf/`, project context snapshots, session
telemetry, assignment capsules, process events, hooks, and chat relay.
